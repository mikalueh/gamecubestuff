#LibPkmGC
This is the LPGLv3-licensed backend library used by PkmGCSaveEditor.